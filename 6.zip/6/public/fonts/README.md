วางไฟล์ฟอนต์ที่นี่:

- THSarabunNew.ttf
- THSarabunNew+Bold.ttf

ถ้าไม่มีไฟล์ฟอนต์ ระบบจะใช้ Tahoma/sans-serif แทน
