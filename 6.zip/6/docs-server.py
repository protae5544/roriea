#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
docs-server corrected minimal

- serve static files
- GET /api/docs
- GET /api/docs/{docId}
- GET /api/qr/{docId}
  ถ้ายังไม่ได้ติดตั้ง qrcode จะ redirect ไปใช้ QR ภายนอกชั่วคราว
"""

import io
import json
import mimetypes
import os
import sqlite3
import urllib.parse
from http.server import HTTPServer, SimpleHTTPRequestHandler, ThreadingHTTPServer

try:
    import qrcode
    from qrcode.image.svg import SvgPathImage
    QRCODE_AVAILABLE = True
except Exception:
    QRCODE_AVAILABLE = False

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8000"))

ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(ROOT, "docs.db")
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")

FIELDS = [f"f{i}" for i in range(1, 13)]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def normalize_fields(row):
    fields = {}

    for i in range(1, 13):
        fields[str(i)] = row.get(f"f{i}", "") or ""

    doc_id = row.get("doc_id", "")
    if doc_id:
        fields["9"] = doc_id

    return fields


class DocsHandler(SimpleHTTPRequestHandler):

    def base_url(self):
        if PUBLIC_BASE_URL:
            return PUBLIC_BASE_URL

        host = (
            self.headers.get("X-Forwarded-Host")
            or self.headers.get("Host")
            or f"localhost:{PORT}"
        )

        proto = (
            self.headers.get("X-Forwarded-Proto")
            or "http"
        )

        return f"{proto}://{host}"

    def send_json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")

        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()

        self.wfile.write(data)

    def send_binary(self, data, content_type, code=200):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()

        self.wfile.write(data)

    def handle_docs_list(self):
        if not os.path.exists(DB_PATH):
            self.send_json({"total": 0, "docs": []})
            return

        conn = get_db()

        try:
            cols = ", ".join(["doc_id"] + FIELDS)

            rows = conn.execute(
                f"SELECT {cols} FROM documents ORDER BY doc_id DESC"
            ).fetchall()

            docs = []

            for r in rows:
                d = dict(r)
                d["fields"] = normalize_fields(d)
                docs.append(d)

            self.send_json({"total": len(docs), "docs": docs})

        except sqlite3.Error as e:
            self.send_json({"error": str(e)}, code=500)

        finally:
            conn.close()

    def handle_doc_one(self, doc_id):
        doc_id = urllib.parse.unquote(doc_id)

        if not os.path.exists(DB_PATH):
            self.send_json({"error": "ไม่พบฐานข้อมูล"}, code=404)
            return

        conn = get_db()

        try:
            cols = ", ".join(["doc_id","3","4","5","6","7","8","9","10","11","12"] + FIELDS)

            row = conn.execute(
                f"SELECT {cols} FROM documents WHERE doc_id = ?",
                (doc_id,)
            ).fetchone()

            if row is None:
                self.send_json({"error": "ไม่พบเอกสาร"}, code=404)
                return

            d = dict(row)
            d["fields"] = normalize_fields(d)

            base = self.base_url()
            verify_url = f"{base}/?" + urllib.parse.urlencode({"doc": doc_id})

            d["verify_url"] = verify_url
            d["qr_url"] = (
                "/api/qr/"
                + urllib.parse.quote(doc_id)
                + "?target="
                + urllib.parse.quote(verify_url)
            )

            self.send_json(d)

        except sqlite3.Error as e:
            self.send_json({"error": str(e)}, code=500)

        finally:
            conn.close()

    def handle_qr(self, doc_id):
        doc_id = urllib.parse.unquote(doc_id)

        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        target = (qs.get("target") or [""])[0]

        if not target:
            target = self.base_url() + "/?" + urllib.parse.urlencode({"doc": doc_id})

        try:
            u = urllib.parse.urlparse(target)
            if u.scheme not in ("http", "https") or not u.netloc:
                raise ValueError("invalid url")
        except Exception:
            self.send_json({"error": "QR target ต้องเป็น http/https"}, code=400)
            return

        # ถ้ายังไม่ได้ติดตั้ง qrcode ให้ redirect ไปใช้ QR ภายนอกชั่วคราว
        if not QRCODE_AVAILABLE:
            fallback = (
                "https://api.qrserver.com/v1/create-qr-code/"
                "?size=320x320&margin=0&ecc=H&data="
                + urllib.parse.quote(target)
            )

            self.send_response(302)
            self.send_header("Location", fallback)
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return

        try:
            qr = qrcode.QRCode(
                version=None,
                error_correction=qrcode.constants.ERROR_CORRECT_H,
                box_size=8,
                border=0
            )

            qr.add_data(target)
            qr.make(fit=True)

            # ถ้ามี Pillow จะสร้าง PNG
            # ถ้าไม่มี จะ fallback เป็น SVG
            try:
                img = qr.make_image(fill_color="black", back_color="white")
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                data = buf.getvalue()
                content_type = "image/png"
            except Exception:
                img = qr.make_image(image_factory=SvgPathImage)
                buf = io.BytesIO()
                img.save(buf)
                data = buf.getvalue()
                content_type = "image/svg+xml"

            self.send_binary(data, content_type)

        except Exception as e:
            self.send_json({"error": "สร้าง QR ไม่สำเร็จ: " + str(e)}, code=500)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/docs":
            self.handle_docs_list()
            return

        if path.startswith("/api/docs/"):
            doc_id = path[len("/api/docs/"):]
            if doc_id:
                self.handle_doc_one(doc_id)
            else:
                self.handle_docs_list()
            return

        if path.startswith("/api/qr/"):
            doc_id = path[len("/api/qr/"):]
            if doc_id:
                self.handle_qr(doc_id)
            else:
                self.send_json({"error": "ไม่พบ doc_id ใน path QR"}, code=404)
            return

        # serve static files
        super().do_GET()

    def translate_path(self, path):
        path = urllib.parse.urlparse(path).path
        path = urllib.parse.unquote(path)
        return super().translate_path(path)

    def end_headers(self):
        if self.path.startswith("/api/"):
            super().end_headers()
            return

        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, fmt, *args):
        print("[docs-server] " + fmt % args)


def main():
    os.chdir(ROOT)

    mimetypes.add_type("image/svg+xml", ".svg")
    mimetypes.add_type("font/ttf", ".ttf")

    try:
        server = ThreadingHTTPServer((HOST, PORT), DocsHandler)
    except OSError:
        server = HTTPServer((HOST, PORT), DocsHandler)

    print(f"docs-server running at http://{HOST}:{PORT}")
    print(f"  list.html       : http://localhost:{PORT}/list.html")
    print(f"  API docs        : http://localhost:{PORT}/api/docs")
    print(f"  API doc one     : http://localhost:{PORT}/api/docs/DOC2026001")
    print(f"  API QR          : http://localhost:{PORT}/api/qr/DOC2026001")

    if PUBLIC_BASE_URL:
        print(f"  PUBLIC_BASE_URL : {PUBLIC_BASE_URL}")

    if not QRCODE_AVAILABLE:
        print("  [!] ยังไม่พบ qrcode")
        print("      ตอนนี้ /api/qr จะ redirect ไปใช้ api.qrserver.com ชั่วคราว")
        print("      ถ้าต้องการให้ server สร้าง QR เอง ให้รัน:")
        print("      pip install 'qrcode[pil]'")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nปิดเซิร์ฟเวอร์แล้ว")


if __name__ == "__main__":
    main()
